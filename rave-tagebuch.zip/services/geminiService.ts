import { GoogleGenAI } from "@google/genai";
import type { Language, NewDJ, Event } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY for Gemini is not set in environment variables. Gemini features will not work.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

const findDjPrompts = {
    de: (djName: string) => `Finde Informationen über den DJ namens "${djName}". Die Antwort MUSS ein JSON-Objekt sein, OHNE Markdown-Formatierung.
Das JSON-Objekt MUSS die folgenden Schlüssel haben: "genre", "city", "imageUrl", "bio".
- "genre": Das Hauptgenre des DJs.
- "city": Die Stadt, mit der der DJ am meisten assoziiert wird.
- "imageUrl": Eine direkte, funktionierende und öffentlich zugängliche URL zu einem Porträtfoto des DJs. Die URL MUSS auf eine Bilddatei verweisen (z.B. .jpg, .jpeg, .png). Dies ist zwingend erforderlich. Gib eine leere Zeichenfolge zurück, wenn keine gültige URL gefunden wird.
- "bio": Eine kurze Biografie von 2-3 Sätzen. Die Biografie MUSS auf Deutsch sein.
Die Antwort darf NUR das JSON-Objekt enthalten.`,
    en: (djName: string) => `Find information about the DJ named "${djName}". The response MUST be a JSON object, with NO markdown formatting.
The JSON object MUST have the following keys: "genre", "city", "imageUrl", "bio".
- "genre": The main genre of the DJ.
- "city": The city the DJ is most associated with.
- "imageUrl": A direct, working, and publicly accessible URL to a portrait photo of the DJ. The URL MUST be a direct link to an image file (e.g., .jpg, .jpeg, .png). This is mandatory. Return an empty string if no valid URL is found.
- "bio": A short biography of 2-3 sentences. The biography MUST be in English.
The response must ONLY contain the JSON object.`
};

const extractJson = (text: string): any | null => {
    try {
        const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/);
        if (jsonMatch && jsonMatch[1]) {
            return JSON.parse(jsonMatch[1]);
        }
        return JSON.parse(text);
    } catch (e) {
        console.error("Failed to parse JSON from model response", e, "Raw text:", text);
        return null;
    }
};

export const findDjInfo = async (djName: string, language: Language): Promise<Omit<NewDJ, 'name'> | null> => {
    if (!API_KEY) {
        console.error("Gemini API key is not configured.");
        return null;
    }
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: findDjPrompts[language](djName),
            config: {
                tools: [{ googleSearch: {} }],
                thinkingConfig: { thinkingBudget: 0 }
            }
        });
        
        const text = response.text;
        const djInfo = extractJson(text);
        if (djInfo && 'bio' in djInfo) {
            return djInfo as Omit<NewDJ, 'name'>;
        }
        return null;
    } catch (error) {
        console.error("Error finding DJ info with Gemini:", error);
        return null;
    }
};

const findEventsPrompts = {
  de: (djName: string) => `Finde die nächsten 3-5 kommenden Events für den DJ "${djName}". Gib die Antwort als JSON-Array zurück, OHNE Markdown-Formatierung. Jedes Objekt im Array muss die Schlüssel "name", "venue" und "date" haben. Die Datumsangaben sollten im Format YYYY-MM-DD sein. Wenn keine Events gefunden werden, gib ein leeres Array zurück.`,
  en: (djName: string) => `Find the next 3-5 upcoming events for the DJ "${djName}". Return the response as a JSON array, with NO markdown formatting. Each object in the array must have the keys "name", "venue", and "date". Dates should be in YYYY-MM-DD format. If no events are found, return an empty array.`,
};

export const findUpcomingEvents = async (djName: string, language: Language): Promise<Event[] | null> => {
    if (!API_KEY) {
        console.error("Gemini API key is not configured.");
        return null;
    }
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: findEventsPrompts[language](djName),
            config: {
                tools: [{ googleSearch: {} }],
                thinkingConfig: { thinkingBudget: 0 }
            }
        });

        const text = response.text;
        const eventsData = extractJson(text);
        if (Array.isArray(eventsData)) {
            return eventsData.map((event, index) => ({ ...event, id: index + 1 }));
        }
        return [];
    } catch (error) {
        console.error("Error finding upcoming events with Gemini:", error);
        return null;
    }
};