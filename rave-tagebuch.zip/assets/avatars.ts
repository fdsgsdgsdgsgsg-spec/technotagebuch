// Function to encode SVG for use in data URLs
const encodeSvg = (svgString: string) => `data:image/svg+xml;base64,${btoa(svgString)}`;

const avatar1 = `
<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#1e3a8a;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#be185d;stop-opacity:1" />
    </linearGradient>
  </defs>
  <rect width="100" height="100" fill="url(#grad1)"/>
  <circle cx="50" cy="50" r="35" fill="#000"/>
  <path d="M30 65 Q 50 80 70 65" stroke="#3b82f6" stroke-width="3" fill="none" />
  <rect x="25" y="35" width="50" height="15" rx="5" fill="#3b82f6" />
  <rect x="25" y="35" width="50" height="5" fill="#93c5fd" />
</svg>
`;

const avatar2 = `
<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
   <defs>
    <radialGradient id="grad2" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
      <stop offset="0%" style="stop-color:#be185d;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#1e40af;stop-opacity:1" />
    </radialGradient>
  </defs>
  <rect width="100" height="100" fill="url(#grad2)"/>
  <circle cx="50" cy="50" r="35" fill="#000"/>
  <path d="M 25 35 C 25 20, 75 20, 75 35 V 60 H 25 Z" fill="#fff"/>
  <path d="M 25 60 H 75 V 75 L 50 65 L 25 75 Z" fill="#fff"/>
  <circle cx="38" cy="48" r="5" fill="black"/>
  <circle cx="62" cy="48" r="5" fill="black"/>
</svg>
`;

const avatar3 = `
<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
   <defs>
    <linearGradient id="grad3" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#4f46e5;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#db2777;stop-opacity:1" />
    </linearGradient>
  </defs>
  <rect width="100" height="100" fill="url(#grad3)"/>
  <circle cx="50" cy="55" r="30" fill="#000"/>
  <path d="M20 50 L 50 20 L 80 50 Z" stroke="#ec4899" stroke-width="3" fill="none" />
  <circle cx="38" cy="55" r="4" fill="#ec4899"/>
  <circle cx="62" cy="55" r="4" fill="#ec4899"/>
  <line x1="45" y1="70" x2="55" y2="70" stroke="#ec4899" stroke-width="3"/>
</svg>
`;

const avatar4 = `
<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
  <rect width="100" height="100" fill="#111827"/>
  <circle cx="50" cy="50" r="35" fill="#000"/>
  <path d="M 20 20 L 50 50 L 20 80 Z" fill="#3b82f6"/>
  <path d="M 80 20 L 50 50 L 80 80 Z" fill="#3b82f6"/>
  <circle cx="50" cy="50" r="10" fill="#ec4899"/>
  <circle cx="50" cy="50" r="5" fill="#fbcfe8"/>
</svg>
`;

const avatar5 = `
<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
  <rect width="100" height="100" fill="#4c1d95"/>
  <circle cx="50" cy="50" r="35" fill="#000"/>
  <path d="M30 40 L70 40 L60 60 L40 60 Z" stroke-width="2" stroke="#a78bfa" fill="#a78bfa" />
  <path d="M40 70 Q 50 80 60 70" stroke-width="2" stroke="#a78bfa" fill="none" />
</svg>
`;

export const AVATARS = [
    encodeSvg(avatar1),
    encodeSvg(avatar2),
    encodeSvg(avatar3),
    encodeSvg(avatar4),
    encodeSvg(avatar5),
];
