import React, { useState } from 'react';
import { useAppContext } from './context/AppContext';
import WelcomeScreen from './screens/WelcomeScreen';
import AuthScreen from './screens/AuthScreen';
import SearchScreen from './screens/SearchScreen';
import DiaryScreen from './screens/DiaryScreen';
import RankScreen from './screens/RankScreen';
import ProfileScreen from './screens/ProfileScreen';
import DJProfileScreen from './screens/DJProfileScreen';
import AdminScreen from './screens/AdminScreen';
import BottomNav from './components/BottomNav';
import UserProfileScreen from './screens/UserProfileScreen';

type AppState = 'welcome' | 'auth' | 'main';

const App: React.FC = () => {
  const { currentUser, activeTab, selectedDJ, isAdmin, selectedUser, selectUser } = useAppContext();
  const [appState, setAppState] = useState<AppState>(currentUser ? 'main' : 'welcome');

  const renderContent = () => {
    if (selectedUser) {
      return <UserProfileScreen user={selectedUser} onBack={() => selectUser(null)} />;
    }
    if (selectedDJ) {
      return <DJProfileScreen dj={selectedDJ} />;
    }

    switch (activeTab) {
      case 'search':
        return <SearchScreen />;
      case 'diary':
        return <DiaryScreen />;
      case 'rank':
        return <RankScreen />;
      case 'profile':
        return <ProfileScreen />;
      case 'admin':
        return isAdmin ? <AdminScreen /> : <SearchScreen />;
      default:
        return <SearchScreen />;
    }
  };
  
  if (!currentUser) {
    if (appState === 'welcome') {
      return <WelcomeScreen onNavigateToAuth={() => setAppState('auth')} />;
    }
    return <AuthScreen />;
  }
  
  return (
    <div className="bg-black text-gray-200 min-h-screen font-sans">
      <div className="container mx-auto max-w-lg h-screen flex flex-col">
        <main className="flex-grow overflow-y-auto pb-20">
          {renderContent()}
        </main>
        <BottomNav />
      </div>
    </div>
  );
};

export default App;