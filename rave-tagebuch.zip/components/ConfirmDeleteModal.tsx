import React from 'react';
import { useLocale } from '../context/LocaleContext';
import Button from './Button';

interface ConfirmDeleteModalProps {
  onClose: () => void;
  onConfirm: () => void;
  title?: string;
  message?: string;
}

const ConfirmDeleteModal: React.FC<ConfirmDeleteModalProps> = ({ onClose, onConfirm, title, message }) => {
  const { t } = useLocale();

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div
        className="bg-gray-900 rounded-lg shadow-lg w-full max-w-sm p-6 border border-pink-500/50 animate-fade-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-2xl font-bold uppercase text-center mb-4 text-pink-400">{title || t('deleteAccountConfirmTitle')}</h2>
        <p className="text-center text-gray-300 mb-6">{message || t('deleteAccountConfirmMessage')}</p>
        <div className="flex justify-center space-x-4">
          <Button type="button" variant="secondary" onClick={onClose}>
            {t('cancelButton')}
          </Button>
          <Button
            type="button"
            onClick={onConfirm}
            className="bg-pink-600 text-white hover:bg-pink-700 shadow-[0_0_15px_rgba(236,72,153,0.5)] hover:shadow-[0_0_25px_rgba(236,72,153,0.7)]"
          >
            {t('deleteAccountConfirmButton')}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmDeleteModal;