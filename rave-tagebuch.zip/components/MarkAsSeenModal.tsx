import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { useLocale } from '../context/LocaleContext';
import type { DJ } from '../types';
import Button from './Button';

interface MarkAsSeenModalProps {
  dj: DJ;
  onClose: () => void;
}

const MarkAsSeenModal: React.FC<MarkAsSeenModalProps> = ({ dj, onClose }) => {
  const { markAsSeen } = useAppContext();
  const { t } = useLocale();
  const [location, setLocation] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]); // Default to today
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!location.trim() || !date) {
      setError(t('validationRequired'));
      return;
    }
    markAsSeen({ djId: dj.id, location, date });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div 
        className="bg-gray-900 rounded-lg shadow-lg w-full max-w-md p-6 border border-blue-500/50 animate-fade-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <h2 className="text-2xl font-black uppercase text-center mb-2 text-blue-400">{t('markAsSeenModalTitle')}</h2>
          <p className="text-center text-lg font-bold text-white -mt-2 mb-6">{dj.name}</p>
          
          <div>
            <label htmlFor="location" className="block text-sm font-bold text-blue-400 mb-1">{t('locationLabel')}</label>
            <input 
              id="location" 
              name="location" 
              type="text" 
              value={location} 
              onChange={(e) => setLocation(e.target.value)} 
              className="w-full bg-gray-800 border-2 border-gray-700 rounded-md px-3 py-2 text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label htmlFor="date" className="block text-sm font-bold text-blue-400 mb-1">{t('dateLabel')}</label>
            <input 
              id="date" 
              name="date" 
              type="date" 
              value={date} 
              onChange={(e) => setDate(e.target.value)} 
              className="w-full bg-gray-800 border-2 border-gray-700 rounded-md px-3 py-2 text-white focus:outline-none focus:border-blue-500"
            />
          </div>
          
          {error && <p className="text-pink-500 text-sm text-center">{error}</p>}

          <div className="flex justify-end space-x-4 pt-4">
            <Button type="button" variant="secondary" onClick={onClose}>{t('cancelButton')}</Button>
            <Button type="submit">{t('saveButton')}</Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MarkAsSeenModal;