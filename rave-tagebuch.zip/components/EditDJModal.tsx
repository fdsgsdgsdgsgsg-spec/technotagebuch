import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { useLocale } from '../context/LocaleContext';
import type { DJ } from '../types';
import Button from './Button';

interface EditDJModalProps {
  dj: DJ;
  onClose: () => void;
}

const EditDJModal: React.FC<EditDJModalProps> = ({ dj, onClose }) => {
  const { updateDj } = useAppContext();
  const { t } = useLocale();
  const [formData, setFormData] = useState<DJ>(dj);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateDj(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div 
        className="bg-gray-900 rounded-lg shadow-lg w-full max-w-md p-6 border border-blue-500/50 animate-fade-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <h2 className="text-2xl font-black uppercase text-center mb-6 text-blue-400">{t('editDjTitle')}</h2>
          
          <div>
            <label htmlFor="name" className="block text-sm font-bold text-blue-400 mb-1">{t('djName')}</label>
            <input id="name" name="name" type="text" value={formData.name} onChange={handleChange} className="w-full bg-gray-800 border-2 border-gray-700 rounded-md px-3 py-2 text-white focus:outline-none focus:border-blue-500"/>
          </div>

          <div>
            <label htmlFor="genre" className="block text-sm font-bold text-blue-400 mb-1">{t('djGenre')}</label>
            <input id="genre" name="genre" type="text" value={formData.genre} onChange={handleChange} className="w-full bg-gray-800 border-2 border-gray-700 rounded-md px-3 py-2 text-white focus:outline-none focus:border-blue-500"/>
          </div>

          <div>
            <label htmlFor="city" className="block text-sm font-bold text-blue-400 mb-1">{t('djCity')}</label>
            <input id="city" name="city" type="text" value={formData.city} onChange={handleChange} className="w-full bg-gray-800 border-2 border-gray-700 rounded-md px-3 py-2 text-white focus:outline-none focus:border-blue-500"/>
          </div>

          <div>
            <label htmlFor="imageUrl" className="block text-sm font-bold text-blue-400 mb-1">{t('djImageUrl')}</label>
            <input id="imageUrl" name="imageUrl" type="text" value={formData.imageUrl} onChange={handleChange} className="w-full bg-gray-800 border-2 border-gray-700 rounded-md px-3 py-2 text-white focus:outline-none focus:border-blue-500"/>
          </div>
          
          <div>
            <label htmlFor="bio" className="block text-sm font-bold text-blue-400 mb-1">{t('djBio')}</label>
            <textarea id="bio" name="bio" value={formData.bio} onChange={handleChange} rows={3} className="w-full bg-gray-800 border-2 border-gray-700 rounded-md px-3 py-2 text-white focus:outline-none focus:border-blue-500"></textarea>
          </div>

          <div className="flex justify-end space-x-4 pt-4">
            <Button type="button" variant="secondary" onClick={onClose}>{t('cancelButton')}</Button>
            <Button type="submit">{t('saveChanges')}</Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditDJModal;