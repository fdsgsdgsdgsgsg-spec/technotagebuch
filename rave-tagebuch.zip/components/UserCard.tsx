import React from 'react';
import type { User } from '../types';
import { useAppContext } from '../context/AppContext';
import { useLocale } from '../context/LocaleContext';

interface UserCardProps {
  user: User;
}

const UserCard: React.FC<UserCardProps> = ({ user }) => {
  const { selectUser } = useAppContext();
  const { t } = useLocale();

  return (
    <div 
      className="flex items-center p-4 bg-gray-900/50 rounded-lg mb-4 cursor-pointer hover:bg-gray-800/70 border border-transparent hover:border-blue-500/50 transition-all duration-300"
      onClick={() => selectUser(user)}
    >
      <img src={user.avatarUrl} alt={user.username} className="w-16 h-16 rounded-full object-cover mr-4 border-2 border-gray-700" />
      <div>
        <h3 className="text-lg font-bold text-white tracking-wide">{user.username}</h3>
        <p className="text-sm text-blue-400 font-semibold">{user.points} {t('pointsAbbreviation')}</p>
      </div>
    </div>
  );
};

export default UserCard;