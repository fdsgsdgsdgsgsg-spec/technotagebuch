import React, { useState, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';
import { useLocale } from '../context/LocaleContext';
import type { NewDJ } from '../types';
import Button from './Button';
import { findDjInfo } from '../services/geminiService';

interface AddDJModalProps {
  onClose: () => void;
}

type ModalState = 'input' | 'loading' | 'confirm' | 'error';

const AddDJModal: React.FC<AddDJModalProps> = ({ onClose }) => {
  const { addDj } = useAppContext();
  const { t, language } = useLocale();
  
  const [modalState, setModalState] = useState<ModalState>('input');
  const [djName, setDjName] = useState('');
  const [foundDj, setFoundDj] = useState<NewDJ | null>(null);
  const [loadingMessageIndex, setLoadingMessageIndex] = useState(0);

  const loadingMessages = [
    t('findingDjMessage1'),
    t('findingDjMessage2'),
    t('findingDjMessage3'),
    t('findingDjMessage4'),
  ];

  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | undefined;
    if (modalState === 'loading') {
      interval = setInterval(() => {
        setLoadingMessageIndex(prevIndex => (prevIndex + 1) % loadingMessages.length);
      }, 2500);
    }
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [modalState, loadingMessages.length]);


  const handleFindDj = async () => {
    if (!djName.trim()) return;
    setModalState('loading');
    const result = await findDjInfo(djName, language);
    if (result) {
      const djData: NewDJ = {
        name: djName,
        ...result,
      };
      setFoundDj(djData);
      setModalState('confirm');
    } else {
      setModalState('error');
    }
  };
  
  const getInitials = (name: string) => {
    const words = name.trim().split(' ');
    if (words.length > 1) {
        return (words[0][0] + words[words.length - 1][0]).toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  const generatePlaceholder = (initials: string) => {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="128" height="128"><rect width="100" height="100" fill="#1f2937"></rect><text x="50" y="55" font-family="Orbitron, sans-serif" font-size="40" fill="#3b82f6" text-anchor="middle" dominant-baseline="middle">${initials}</text></svg>`;
    return `data:image/svg+xml;base64,${btoa(svg)}`;
  };

  const handleAddDj = () => {
    if (foundDj) {
       const initials = getInitials(foundDj.name);
       const finalImageUrl = foundDj.imageUrl && (foundDj.imageUrl.startsWith('http') || foundDj.imageUrl.startsWith('data:')) 
            ? foundDj.imageUrl 
            : generatePlaceholder(initials);
      addDj({ ...foundDj, imageUrl: finalImageUrl });
      onClose();
    }
  };
  
  const handleTryAgain = () => {
      setDjName('');
      setFoundDj(null);
      setModalState('input');
  };

  const renderContent = () => {
    switch (modalState) {
      case 'loading':
        return (
          <div className="text-center p-8">
            <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500 mx-auto"></div>
            <p className="mt-4 text-lg font-bold text-blue-400 transition-opacity duration-500">{loadingMessages[loadingMessageIndex]}</p>
          </div>
        );
      case 'error':
        return (
          <div className="text-center p-4">
            <h3 className="text-xl font-bold uppercase text-pink-400 mb-4">{t('djNotFoundErrorTitle')}</h3>
            <p className="text-gray-400 mb-6">{t('djNotFoundErrorBody')}</p>
            <Button onClick={handleTryAgain}>{t('tryAgainButton')}</Button>
          </div>
        );
      case 'confirm':
        if (!foundDj) return null;
        const initials = getInitials(foundDj.name);
        const imageUrl = foundDj.imageUrl && (foundDj.imageUrl.startsWith('http') || foundDj.imageUrl.startsWith('data:')) 
            ? foundDj.imageUrl 
            : generatePlaceholder(initials);
        return (
          <div>
            <h2 className="text-2xl font-black uppercase text-center mb-4 text-blue-400">{t('confirmDjTitle')}</h2>
            <div className="flex flex-col items-center text-center">
                <img src={imageUrl} alt={foundDj.name} className="w-32 h-32 rounded-full object-cover mb-4 border-4 border-gray-700 bg-gray-800" />
                <h3 className="text-2xl font-bold">{foundDj.name}</h3>
                <p className="text-md text-blue-400 font-semibold">{foundDj.genre} - {foundDj.city}</p>
                <p className="text-sm text-gray-400 mt-2 max-h-24 overflow-y-auto p-1">{foundDj.bio}</p>
            </div>
            <div className="flex justify-end space-x-4 pt-6">
                <Button type="button" variant="secondary" onClick={handleTryAgain}>{t('tryAgainButton')}</Button>
                <Button type="button" onClick={handleAddDj}>{t('addThisDjButton')}</Button>
            </div>
          </div>
        );
      case 'input':
      default:
        return (
          <>
            <h2 className="text-2xl font-black uppercase text-center mb-6 text-blue-400">{t('addDjTitle')}</h2>
            <div>
              <label htmlFor="djName" className="block text-sm font-bold text-blue-400 mb-2">{t('djName')}</label>
              <input 
                id="djName" 
                type="text" 
                value={djName}
                onChange={(e) => setDjName(e.target.value)}
                placeholder={t('djNamePlaceholder')}
                className="w-full bg-gray-800 border-2 border-gray-700 rounded-md px-3 py-2 text-white focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>
            <div className="flex justify-end space-x-4 pt-6">
              <Button type="button" variant="secondary" onClick={onClose}>{t('cancelButton')}</Button>
              <Button type="button" onClick={handleFindDj} disabled={!djName.trim()}>{t('findDjButton')}</Button>
            </div>
          </>
        );
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div 
        className="bg-gray-900 rounded-lg shadow-lg w-full max-w-md p-6 border border-blue-500/50 animate-fade-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        {renderContent()}
      </div>
    </div>
  );
};

export default AddDJModal;