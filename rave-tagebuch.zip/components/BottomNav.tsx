import React from 'react';
import { useAppContext } from '../context/AppContext';
import { useLocale } from '../context/LocaleContext';
import type { Tab } from '../types';
import { SearchIcon } from './icons/SearchIcon';
import { BookOpenIcon } from './icons/BookOpenIcon';
import { TrophyIcon } from './icons/TrophyIcon';
import { UserIcon } from './icons/UserIcon';
import { CogIcon } from './icons/CogIcon';

const NavItem: React.FC<{ tab: Tab; label: string; children: React.ReactNode }> = ({ tab, label, children }) => {
  const { activeTab, setActiveTab, selectDJ, selectUser } = useAppContext();
  const isActive = activeTab === tab;

  const handleClick = () => {
    setActiveTab(tab);
    selectDJ(null);
    selectUser(null);
  };

  return (
    <button
      onClick={handleClick}
      className={`flex flex-col items-center justify-center w-full pt-2 pb-1 transition-colors duration-200 ${
        isActive ? 'text-blue-400' : 'text-gray-500 hover:text-blue-400'
      }`}
      aria-label={label}
    >
      {children}
      <span className={`text-xs font-bold mt-1 ${isActive ? 'text-blue-400' : 'text-gray-500'}`}>{label}</span>
    </button>
  );
};

const BottomNav: React.FC = () => {
  const { t } = useLocale();
  const { isAdmin } = useAppContext();
  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto bg-black border-t border-gray-800 shadow-[0_-5px_15px_-5px_rgba(59,130,246,0.2)]">
      <div className="flex justify-around h-16">
        <NavItem tab="search" label={t('navSearch')}>
          <SearchIcon />
        </NavItem>
        <NavItem tab="diary" label={t('navDiary')}>
          <BookOpenIcon />
        </NavItem>
        <NavItem tab="rank" label={t('navRank')}>
          <TrophyIcon />
        </NavItem>
        <NavItem tab="profile" label={t('navProfile')}>
          <UserIcon />
        </NavItem>
        {isAdmin && (
          <NavItem tab="admin" label={t('navAdmin')}>
            <CogIcon />
          </NavItem>
        )}
      </div>
    </nav>
  );
};

export default BottomNav;