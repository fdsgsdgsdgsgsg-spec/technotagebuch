import React, { createContext, useState, useContext, ReactNode, useCallback, useEffect } from 'react';
import type { Language } from '../types';

type Translations = Record<string, string>;

interface LocaleContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LocaleContext = createContext<LocaleContextType | undefined>(undefined);

// Cache for loaded translations
const translationsCache: Partial<Record<Language, Translations>> = {};

export const LocaleProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('de');
  const [currentTranslations, setCurrentTranslations] = useState<Translations | null>(null);

  useEffect(() => {
    const loadTranslations = async (lang: Language) => {
      // Use cache if available
      if (translationsCache[lang]) {
        setCurrentTranslations(translationsCache[lang]!);
        return;
      }

      try {
        // Paths must be relative to the root HTML file.
        const response = await fetch(`./locales/${lang}.json`);
        if (!response.ok) {
          throw new Error(`Failed to fetch translations for ${lang}`);
        }
        const data: Translations = await response.json();
        translationsCache[lang] = data; // Cache the fetched translations
        setCurrentTranslations(data);
      } catch (error) {
        console.error(error);
        // Set empty translations on failure to prevent app crash
        setCurrentTranslations({});
      }
    };

    loadTranslations(language);
  }, [language]);

  const t = useCallback((key: string): string => {
    // Return the key itself if translations are not loaded or the key doesn't exist
    return currentTranslations?.[key] || key;
  }, [currentTranslations]);

  const value = {
    language,
    setLanguage,
    t,
  };

  // Do not render children until the initial language file is loaded.
  // This prevents rendering with untranslated keys.
  if (!currentTranslations) {
    return null;
  }

  return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>;
};

export const useLocale = (): LocaleContextType => {
  const context = useContext(LocaleContext);
  if (context === undefined) {
    throw new Error('useLocale must be used within a LocaleProvider');
  }
  return context;
};
