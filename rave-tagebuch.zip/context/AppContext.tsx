import React, { createContext, useState, useContext, ReactNode, useMemo, useCallback, useEffect } from 'react';
import type { Tab, User, DJ, SeenDJ, NewDJ } from '../types';
import { MOCK_DJS } from '../data/mockData';
import { AVATARS } from '../assets/avatars';

const STORAGE_KEYS = {
  DJS: 'rave_diary_djs',
  USERS: 'rave_diary_users',
  SEEN_DJS: 'rave_diary_seen_djs',
  CURRENT_USER: 'rave_diary_current_user',
};

interface AppContextType {
  currentUser: User | null;
  isAdmin: boolean;
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (username: string, password: string, avatarUrl: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  deleteCurrentUser: () => void;
  deleteUserById: (userId: number) => void;
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
  djs: DJ[];
  addDj: (djData: NewDJ) => void;
  updateDj: (updatedDj: DJ) => void;
  deleteDj: (djId: number) => void;
  users: User[];
  seenDjs: SeenDJ[];
  allSeenDjs: Record<number, SeenDJ[]>;
  markAsSeen: (data: { djId: number; location: string; date: string }) => void;
  selectedDJ: DJ | null;
  selectDJ: (dj: DJ | null) => void;
  selectedUser: User | null;
  selectUser: (user: User | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const migrateUsers = (users: any[]): User[] => {
    return users.map(user => ({
        ...user,
        avatarUrl: user.avatarUrl || AVATARS[0],
    }));
};

const migrateSeenDjs = (allSeenDjsData: Record<string, any[]>): Record<string, SeenDJ[]> => {
    const migratedData: Record<string, SeenDJ[]> = {};
    for (const userId in allSeenDjsData) {
        if (Array.isArray(allSeenDjsData[userId])) {
            migratedData[userId] = allSeenDjsData[userId].map(entry => {
                if (entry && typeof entry === 'object' && !('id' in entry) && 'djId' in entry && 'seenDate' in entry) {
                    return {
                        id: crypto.randomUUID(),
                        djId: entry.djId,
                        date: new Date(entry.seenDate).toISOString().split('T')[0],
                        location: 'Unknown Event'
                    };
                }
                return entry;
            }).filter(e => e && e.id);
        }
    }
    return migratedData;
};

const initializeData = <T,>(key: string, mockData: T, migrator?: (data: any) => T): T => {
  try {
    const storedData = localStorage.getItem(key);
    if (storedData) {
      let parsedData = JSON.parse(storedData);
      if (migrator) {
          parsedData = migrator(parsedData);
      }
      return parsedData;
    }
  } catch (error) {
    console.error(`Error reading ${key} from localStorage`, error);
  }
  if (key === STORAGE_KEYS.DJS) {
    localStorage.setItem(key, JSON.stringify(mockData));
    return mockData;
  }
  const emptyState = Array.isArray(mockData) ? [] : {};
  localStorage.setItem(key, JSON.stringify(emptyState));
  return emptyState as T;
};

const getCurrentUserFromStorage = (): User | null => {
    try {
        const storedUser = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
        if (!storedUser) return null;
        const user = JSON.parse(storedUser);
        return {
            ...user,
            avatarUrl: user.avatarUrl || (user.username === 'admin' ? AVATARS[4] : AVATARS[0]),
        };
    } catch (error) {
        console.error("Error reading current user from storage", error);
        return null;
    }
}

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(getCurrentUserFromStorage);
  const [isAdmin, setIsAdmin] = useState<boolean>(() => getCurrentUserFromStorage()?.username === 'admin');
  const [activeTab, setActiveTab] = useState<Tab>('search');
  const [selectedDJ, setSelectedDJ] = useState<DJ | null>(null);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  
  const [djs, setDjs] = useState<DJ[]>(() => initializeData(STORAGE_KEYS.DJS, MOCK_DJS));
  const [users, setUsers] = useState<User[]>(() => initializeData(STORAGE_KEYS.USERS, [], migrateUsers));
  const [allSeenDjs, setAllSeenDjs] = useState<Record<number, SeenDJ[]>>(() => initializeData(STORAGE_KEYS.SEEN_DJS, {}, migrateSeenDjs));

  const recalculateAllUserPoints = useCallback(() => {
    const djPopularity = new Map<number, number>();
    Object.values(allSeenDjs).forEach(userSeenList => {
        const uniqueDjIds = new Set(userSeenList.map(entry => entry.djId));
        uniqueDjIds.forEach(djId => {
            djPopularity.set(djId, (djPopularity.get(djId) || 0) + 1);
        });
    });

    setUsers(prevUsers => {
        const updatedUsers = prevUsers.map(user => {
            const userSeenList = allSeenDjs[user.id] || [];
            const totalPoints = userSeenList.reduce((sum, entry) => {
                return sum + (djPopularity.get(entry.djId) || 0);
            }, 0);
            return { ...user, points: totalPoints };
        });

        if (JSON.stringify(prevUsers) !== JSON.stringify(updatedUsers)) {
             localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(updatedUsers));
             if (currentUser) {
                const updatedCurrentUser = updatedUsers.find(u => u.id === currentUser.id);
                if (updatedCurrentUser && updatedCurrentUser.points !== currentUser.points) {
                    setCurrentUser(updatedCurrentUser);
                    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(updatedCurrentUser));
                }
            }
        }
        return updatedUsers;
    });
  }, [allSeenDjs, currentUser]);

  useEffect(() => {
    recalculateAllUserPoints();
  }, [allSeenDjs, recalculateAllUserPoints]);

  const login = useCallback(async (username: string, password: string): Promise<{ success: boolean; error?: string }> => {
    const allUsersFromStorage = initializeData<User[]>(STORAGE_KEYS.USERS, [], migrateUsers);
    if (username.toLowerCase() === 'admin' && password === '1234') { 
        const adminUser: User = { id: 0, username: 'admin', points: 9999, avatarUrl: AVATARS[4] };
        setCurrentUser(adminUser);
        setIsAdmin(true);
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(adminUser));
        setActiveTab('search');
        return { success: true };
    }

    const user = allUsersFromStorage.find(u => u.username.toLowerCase() === username.toLowerCase());
    if (user && user.password === password) {
      setCurrentUser(user);
      setIsAdmin(false);
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
      setActiveTab('search');
      return { success: true };
    }
    return { success: false, error: 'errorInvalidCredentials' };
  }, []);

  const register = useCallback(async (username: string, password: string, avatarUrl: string): Promise<{ success: boolean; error?: string }> => {
    const currentUsers = initializeData<User[]>(STORAGE_KEYS.USERS, [], migrateUsers);
    if (currentUsers.some(u => u.username.toLowerCase() === username.toLowerCase()) || username.toLowerCase() === 'admin') {
        return { success: false, error: 'errorUserExists' };
    }
    const newId = currentUsers.length > 0 ? Math.max(...currentUsers.map(u => u.id)) + 1 : 1;
    const newUser: User = { id: newId, username, password, points: 0, avatarUrl };
    
    const updatedUsers = [...currentUsers, newUser];
    setUsers(updatedUsers);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(updatedUsers));

    setCurrentUser(newUser);
    setIsAdmin(false);
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(newUser));
    setActiveTab('search');

    return { success: true };
  }, []);

  const logout = useCallback(() => {
    setCurrentUser(null);
    setIsAdmin(false);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    setActiveTab('search');
    setSelectedDJ(null);
    setSelectedUser(null);
  }, []);
  
  const deleteUserById = useCallback((userId: number) => {
    setUsers(prevUsers => {
        const updatedUsers = prevUsers.filter(u => u.id !== userId);
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(updatedUsers));
        return updatedUsers;
    });

    setAllSeenDjs(prevAllSeen => {
        const updatedAllSeenDjs = { ...prevAllSeen };
        delete updatedAllSeenDjs[userId];
        localStorage.setItem(STORAGE_KEYS.SEEN_DJS, JSON.stringify(updatedAllSeenDjs));
        return updatedAllSeenDjs;
    });
  }, []);

  const deleteCurrentUser = useCallback(() => {
    if (!currentUser || currentUser.username === 'admin') return;
    deleteUserById(currentUser.id);
    logout();
  }, [currentUser, deleteUserById, logout]);

  const selectDJ = (dj: DJ | null) => {
    setSelectedDJ(dj);
  };
  
  const selectUser = (user: User | null) => {
    setSelectedUser(user);
  };
  
  const seenDjsForCurrentUser = useMemo(() => {
    if (!currentUser) return [];
    return allSeenDjs[currentUser.id] || [];
  }, [currentUser, allSeenDjs]);

  const markAsSeen = useCallback((data: { djId: number; location: string; date: string }) => {
    if (!currentUser || isAdmin) return;

    const newSeenEntry: SeenDJ = {
        id: crypto.randomUUID(),
        djId: data.djId,
        location: data.location,
        date: data.date,
    };

    setAllSeenDjs(prevAllSeen => {
        const updatedSeenForUser = [...(prevAllSeen[currentUser.id] || []), newSeenEntry];
        const updatedAllSeen = { ...prevAllSeen, [currentUser.id]: updatedSeenForUser };
        localStorage.setItem(STORAGE_KEYS.SEEN_DJS, JSON.stringify(updatedAllSeen));
        return updatedAllSeen;
    });
  }, [currentUser, isAdmin]);

  const addDj = useCallback((djData: NewDJ) => {
    const newId = djs.length > 0 ? Math.max(...djs.map(d => d.id)) + 1 : 1;
    const newDj: DJ = { ...djData, id: newId };
    const updatedDjs = [...djs, newDj];
    setDjs(updatedDjs);
    localStorage.setItem(STORAGE_KEYS.DJS, JSON.stringify(updatedDjs));
  }, [djs]);

  const updateDj = useCallback((updatedDj: DJ) => {
    const updatedDjs = djs.map(dj => dj.id === updatedDj.id ? updatedDj : dj);
    setDjs(updatedDjs);
    localStorage.setItem(STORAGE_KEYS.DJS, JSON.stringify(updatedDjs));
  }, [djs]);

  const deleteDj = useCallback((djId: number) => {
    const updatedDjs = djs.filter(d => d.id !== djId);
    setDjs(updatedDjs);
    localStorage.setItem(STORAGE_KEYS.DJS, JSON.stringify(updatedDjs));

    setAllSeenDjs(prevAllSeen => {
        const updatedAllSeenDjs = { ...prevAllSeen };
        Object.keys(updatedAllSeenDjs).forEach(userIdStr => {
            const userId = parseInt(userIdStr, 10);
            updatedAllSeenDjs[userId] = updatedAllSeenDjs[userId].filter(seen => seen.djId !== djId);
        });
        localStorage.setItem(STORAGE_KEYS.SEEN_DJS, JSON.stringify(updatedAllSeenDjs));
        return updatedAllSeenDjs;
    });
  }, [djs]);

  const value = useMemo(() => ({
    currentUser,
    isAdmin,
    login,
    register,
    logout,
    deleteCurrentUser,
    deleteUserById,
    activeTab,
    setActiveTab,
    djs,
    addDj,
    updateDj,
    deleteDj,
    users: [...users].sort((a, b) => b.points - a.points),
    seenDjs: seenDjsForCurrentUser,
    allSeenDjs,
    markAsSeen,
    selectedDJ,
    selectDJ,
    selectedUser,
    selectUser,
  }), [currentUser, isAdmin, login, register, logout, deleteCurrentUser, deleteUserById, activeTab, djs, addDj, updateDj, deleteDj, users, seenDjsForCurrentUser, allSeenDjs, markAsSeen, selectedDJ, selectedUser]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};