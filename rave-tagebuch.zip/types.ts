export interface DJ {
  id: number;
  name: string;
  genre: string;
  city: string;
  imageUrl: string;
  bio: string;
  upcomingEvents?: Event[];
}

export type NewDJ = Omit<DJ, 'id' | 'upcomingEvents'>;

export interface Event {
  id: number;
  name: string;
  date: string;
  venue: string;
}

export interface User {
  id: number;
  username: string;
  password?: string;
  email?: string;
  points: number;
  avatarUrl: string;
}

export interface SeenDJ {
  id: string; // Unique identifier for each diary entry
  djId: number;
  location: string;
  date: string; // YYYY-MM-DD format
}

export type Tab = 'search' | 'diary' | 'rank' | 'profile' | 'admin';

export type Language = 'de' | 'en';