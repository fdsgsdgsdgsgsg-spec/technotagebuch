import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { useLocale } from '../context/LocaleContext';
import Button from '../components/Button';
import { AVATARS } from '../assets/avatars';

type Mode = 'login' | 'register';

const AuthScreen: React.FC = () => {
  const { login, register } = useAppContext();
  const { t } = useLocale();
  const [mode, setMode] = useState<Mode>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState<string>('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const toggleMode = () => {
    setMode(prev => prev === 'login' ? 'register' : 'login');
    setError('');
    setUsername('');
    setPassword('');
    setSelectedAvatar('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    if (!username || !password) {
        setError(t('validationRequired'));
        setIsLoading(false);
        return;
    }
    
    if (mode === 'register' && !selectedAvatar) {
        setError(t('errorAvatarRequired'));
        setIsLoading(false);
        return;
    }

    const result = mode === 'login' 
      ? await login(username, password)
      : await register(username, password, selectedAvatar);

    if (result && !result.success && result.error) {
      setError(t(result.error));
    }
    
    setIsLoading(false);
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-black text-white p-6">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-black uppercase tracking-tighter text-blue-400" style={{ textShadow: '0 0 10px rgba(59, 130, 246, 0.7)' }}>
            {mode === 'login' ? t('authLoginTitle') : t('authRegisterTitle')}
          </h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="username" className="block text-sm font-bold text-blue-400 mb-2">{t('username')}</label>
            <input 
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-gray-900 border-2 border-gray-700 rounded-md px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>
          <div>
            <label htmlFor="password"className="block text-sm font-bold text-blue-400 mb-2">{t('password')}</label>
            <input 
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-gray-900 border-2 border-gray-700 rounded-md px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>

          {mode === 'register' && (
            <div>
              <label className="block text-sm font-bold text-blue-400 mb-2">{t('selectAvatar')}</label>
              <div className="flex justify-around items-center bg-gray-900 border-2 border-gray-700 rounded-md p-2">
                {AVATARS.map((avatar, index) => (
                  <button 
                    type="button" 
                    key={index} 
                    onClick={() => setSelectedAvatar(avatar)}
                    className={`w-16 h-16 rounded-full transition-all duration-200 ${selectedAvatar === avatar ? 'border-4 border-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.5)]' : 'border-2 border-transparent hover:border-blue-500'}`}
                  >
                    <img src={avatar} alt={`Avatar ${index + 1}`} className="w-full h-full rounded-full object-cover" />
                  </button>
                ))}
              </div>
            </div>
          )}
          
          {error && <p className="text-pink-500 text-sm text-center">{error}</p>}

          <div>
            <Button type="submit" className="w-full text-lg py-3" disabled={isLoading}>
              {isLoading ? '...' : (mode === 'login' ? t('authLoginButton') : t('registerButton'))}
            </Button>
          </div>
        </form>

        <div className="mt-6 text-center">
          <button onClick={toggleMode} className="text-sm text-blue-400 hover:text-blue-300 hover:underline">
            {mode === 'login' ? t('authSwitchToRegister') : t('authSwitchToLogin')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthScreen;