import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useAppContext } from '../context/AppContext';
import { useLocale } from '../context/LocaleContext';
import DJCard from '../components/DJCard';
import AddDJModal from '../components/AddDJModal';
import { PlusIcon } from '../components/icons/PlusIcon';
import UserCard from '../components/UserCard';
import { ChevronDownIcon } from '../components/icons/ChevronDownIcon';

type SearchMode = 'djs' | 'users';

const SearchScreen: React.FC = () => {
  const { djs, users, currentUser } = useAppContext();
  const { t } = useLocale();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeGenre, setActiveGenre] = useState('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchMode, setSearchMode] = useState<SearchMode>('djs');
  const [isGenreDropdownOpen, setIsGenreDropdownOpen] = useState(false);
  const [genreSearchTerm, setGenreSearchTerm] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);

  const genres = useMemo(() => {
    const allGenres = djs.reduce((acc, dj) => {
        dj.genre.split(',').forEach(g => {
            const trimmed = g.trim();
            if (trimmed && !acc.includes(trimmed)) {
                acc.push(trimmed);
            }
        });
        return acc;
    }, [] as string[]);
    return ['All', ...[...new Set(allGenres)].sort()];
  }, [djs]);

  const filteredGenres = useMemo(() => {
    return genres.filter(g => g.toLowerCase().includes(genreSearchTerm.toLowerCase()));
  }, [genres, genreSearchTerm]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsGenreDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleGenreSelect = (genre: string) => {
    setActiveGenre(genre);
    setIsGenreDropdownOpen(false);
    setGenreSearchTerm('');
  };

  const filteredDjs = useMemo(() => {
    return djs.filter(dj => {
      const nameMatch = dj.name.toLowerCase().includes(searchTerm.toLowerCase());
      const genreMatch = activeGenre === 'All' || dj.genre.toLowerCase().includes(activeGenre.toLowerCase());
      return nameMatch && genreMatch;
    }).sort((a,b) => a.name.localeCompare(b.name));
  }, [djs, searchTerm, activeGenre]);

  const filteredUsers = useMemo(() => {
    if (!users) return [];
    return users.filter(user => 
        user.username.toLowerCase().includes(searchTerm.toLowerCase()) && user.id !== currentUser?.id
    );
  }, [users, searchTerm, currentUser]);


  return (
    <div className="p-4 relative min-h-screen">
      <h1 className="text-3xl font-black uppercase text-center my-4 text-blue-400">{t('searchTitle')}</h1>
      
      <div className="flex justify-center my-4 bg-gray-900 rounded-full p-1">
        <button
          onClick={() => setSearchMode('djs')}
          className={`w-1/2 py-2 text-center font-bold rounded-full transition-colors ${searchMode === 'djs' ? 'bg-blue-500 text-white' : 'text-gray-400'}`}
        >
          {t('searchDJs')}
        </button>
        <button
          onClick={() => setSearchMode('users')}
          className={`w-1/2 py-2 text-center font-bold rounded-full transition-colors ${searchMode === 'users' ? 'bg-blue-500 text-white' : 'text-gray-400'}`}
        >
          {t('searchUsers')}
        </button>
      </div>

      <div className="sticky top-0 bg-black py-2 z-10">
        <input
          type="text"
          placeholder={searchMode === 'djs' ? t('searchPlaceholder') : t('userSearchPlaceholder')}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-gray-900 border-2 border-gray-700 rounded-full px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors"
        />
        {searchMode === 'djs' && (
          <div className="relative mt-4" ref={dropdownRef}>
            <button
              onClick={() => setIsGenreDropdownOpen(!isGenreDropdownOpen)}
              className="w-full flex justify-between items-center bg-gray-800 border-2 border-gray-700 rounded-full px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors"
            >
              <span>{activeGenre === 'All' ? t('genreFilterButton') : activeGenre}</span>
              <ChevronDownIcon />
            </button>
            {isGenreDropdownOpen && (
              <div className="absolute top-full mt-2 w-full bg-gray-900 border border-gray-700 rounded-lg shadow-lg z-20 max-h-60 overflow-y-auto">
                 <input
                    type="text"
                    placeholder={t('genreSearchPlaceholder')}
                    value={genreSearchTerm}
                    onChange={(e) => setGenreSearchTerm(e.target.value)}
                    className="w-full bg-gray-800 border-b border-gray-700 px-4 py-2 text-white focus:outline-none"
                  />
                <ul>
                  {filteredGenres.map(genre => (
                    <li
                      key={genre}
                      onClick={() => handleGenreSelect(genre)}
                      className="px-4 py-2 text-white hover:bg-blue-500/20 cursor-pointer"
                    >
                      {genre}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
      <div className="mt-4">
        {searchMode === 'djs' && (
           <>
            {filteredDjs.length > 0 ? (
              filteredDjs.map(dj => <DJCard key={dj.id} dj={dj} />)
            ) : (
              <p className="text-center text-gray-500 mt-8">{t('noDjsFound')}</p>
            )}
           </>
        )}
         {searchMode === 'users' && (
           <>
            {filteredUsers.length > 0 ? (
              filteredUsers.map(user => <UserCard key={user.id} user={user} />)
            ) : (
              <p className="text-center text-gray-500 mt-8">{t('noUsersFound')}</p>
            )}
           </>
        )}
      </div>

      {searchMode === 'djs' && (
        <button
            onClick={() => setIsModalOpen(true)}
            className="fixed bottom-24 right-4 bg-pink-500 text-white p-4 rounded-full shadow-[0_0_20px_rgba(236,72,153,0.7)] hover:bg-pink-600 transition-all duration-300 z-20"
            aria-label={t('addDjButton')}
        >
            <PlusIcon />
        </button>
      )}

      {isModalOpen && <AddDJModal onClose={() => setIsModalOpen(false)} />}
    </div>
  );
};

export default SearchScreen;