import React from 'react';
import type { User, DJ, SeenDJ } from '../types';
import { useAppContext } from '../context/AppContext';
import { useLocale } from '../context/LocaleContext';
import { ArrowLeftIcon } from '../components/icons/ArrowLeftIcon';
import { MapPinIcon } from '../components/icons/MapPinIcon';
import { CalendarIcon } from '../components/icons/CalendarIcon';

interface UserProfileScreenProps {
  user: User;
  onBack: () => void;
}

const UserProfileScreen: React.FC<UserProfileScreenProps> = ({ user, onBack }) => {
  const { djs, allSeenDjs, selectDJ } = useAppContext();
  const { t } = useLocale();
  
  const userSeenDjs = allSeenDjs[user.id] || [];

  const diaryEntries = userSeenDjs
    .map(seenEntry => {
      const dj = djs.find(d => d.id === seenEntry.djId);
      return dj ? { ...seenEntry, dj } : null;
    })
    .filter((entry): entry is SeenDJ & { dj: DJ } => entry !== null)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="animate-fade-in">
        <div className="relative flex items-center justify-center p-4 border-b border-gray-800">
            <button 
                onClick={onBack} 
                className="absolute left-4 bg-gray-800/80 p-2 rounded-full text-white hover:bg-gray-700 transition-colors"
            >
                <ArrowLeftIcon />
            </button>
            <h1 className="text-2xl font-black uppercase text-blue-400">{t('profileTitle')}</h1>
        </div>

        <div className="p-4">
            <div className="flex flex-col items-center mt-4">
                <img src={user.avatarUrl} alt={user.username} className="w-32 h-32 rounded-full object-cover border-4 border-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.5)]" />
                <h2 className="mt-4 text-3xl font-bold text-white">{user.username}</h2>
            </div>

            <div className="mt-10 grid grid-cols-2 gap-4 text-center">
                <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-800">
                <p className="text-sm uppercase text-blue-400 font-bold tracking-wider">{t('djsSeenStat')}</p>
                <p className="text-4xl font-black text-white">{diaryEntries.length}</p>
                </div>
                <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-800">
                <p className="text-sm uppercase text-blue-400 font-bold tracking-wider">{t('totalPointsStat')}</p>
                <p className="text-4xl font-black text-white">{user.points}</p>
                </div>
            </div>

            <div className="mt-10">
                <h2 className="text-2xl font-bold uppercase text-blue-400 mb-4">{t('userDiaryTitle').replace('{username}', user.username)}</h2>
                {diaryEntries.length > 0 ? (
                    <div className="space-y-4">
                    {diaryEntries.map((entry) => (
                        <div 
                        key={entry.id}
                        onClick={() => { onBack(); selectDJ(entry.dj); }}
                        className="flex items-center p-4 bg-gray-900/50 rounded-lg cursor-pointer hover:bg-gray-800/70 border border-transparent hover:border-blue-500/50 transition-all duration-300"
                        >
                        <img src={entry.dj.imageUrl} alt={entry.dj.name} className="w-16 h-16 rounded-full object-cover mr-4 border-2 border-gray-700" />
                        <div className="flex-grow">
                            <h3 className="text-lg font-bold text-white">{entry.dj.name}</h3>
                            <div className="flex items-center mt-1 text-sm text-blue-400 font-semibold">
                            <MapPinIcon className="w-4 h-4 mr-2 flex-shrink-0" />
                            <span>{entry.location}</span>
                            </div>
                            <div className="flex items-center mt-1 text-xs text-gray-400">
                            <CalendarIcon className="w-4 h-4 mr-2 flex-shrink-0" />
                            <span>{new Date(entry.date).toLocaleDateString()}</span>
                            </div>
                        </div>
                        </div>
                    ))}
                    </div>
                ) : (
                    <div className="text-center mt-8">
                        <p className="text-gray-500">{t('diaryEmptyTitle')}</p>
                    </div>
                )}
            </div>
        </div>
    </div>
  );
};

export default UserProfileScreen;