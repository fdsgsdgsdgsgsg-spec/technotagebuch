import React from 'react';
import { useAppContext } from '../context/AppContext';
import { useLocale } from '../context/LocaleContext';
import type { DJ, SeenDJ } from '../types';
import { MapPinIcon } from '../components/icons/MapPinIcon';
import { CalendarIcon } from '../components/icons/CalendarIcon';

const DiaryScreen: React.FC = () => {
  const { djs, seenDjs, selectDJ } = useAppContext();
  const { t } = useLocale();
  
  const diaryEntries = seenDjs
    .map(seenEntry => {
      const dj = djs.find(d => d.id === seenEntry.djId);
      return dj ? { ...seenEntry, dj } : null;
    })
    .filter((entry): entry is SeenDJ & { dj: DJ } => entry !== null)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="p-4">
      <h1 className="text-3xl font-black uppercase text-center my-4 text-blue-400">{t('diaryTitle')}</h1>
      {diaryEntries.length > 0 ? (
        <div className="space-y-4">
          {diaryEntries.map((entry) => (
            <div 
              key={entry.id}
              onClick={() => selectDJ(entry.dj)}
              className="flex items-center p-4 bg-gray-900/50 rounded-lg cursor-pointer hover:bg-gray-800/70 border border-transparent hover:border-blue-500/50 transition-all duration-300"
            >
              <img src={entry.dj.imageUrl} alt={entry.dj.name} className="w-16 h-16 rounded-full object-cover mr-4 border-2 border-gray-700" />
              <div className="flex-grow">
                <h3 className="text-lg font-bold text-white">{entry.dj.name}</h3>
                <div className="flex items-center mt-1 text-sm text-blue-400 font-semibold">
                  <MapPinIcon className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span>{entry.location}</span>
                </div>
                 <div className="flex items-center mt-1 text-xs text-gray-400">
                  <CalendarIcon className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span>{new Date(entry.date).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center mt-20">
          <p className="text-gray-500 text-lg">{t('diaryEmptyTitle')}</p>
          <p className="text-gray-600 mt-2">{t('diaryEmptySubtitle')}</p>
        </div>
      )}
    </div>
  );
};

export default DiaryScreen;