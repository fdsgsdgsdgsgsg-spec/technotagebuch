import React from 'react';
import { useLocale } from '../context/LocaleContext';
import Button from '../components/Button';

interface WelcomeScreenProps {
  onNavigateToAuth: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onNavigateToAuth }) => {
  const { t } = useLocale();

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-black text-white p-6">
      <div className="text-center">
        <h1 className="text-5xl font-black uppercase tracking-tighter text-blue-400" style={{ textShadow: '0 0 10px rgba(59, 130, 246, 0.7)' }}>
          {t('appName')}
        </h1>
        <p className="mt-4 text-lg text-gray-300 max-w-md mx-auto">
          {t('welcomeSubtitle')}
        </p>
      </div>
      <div className="mt-12">
        <Button onClick={onNavigateToAuth} className="px-10 py-4 text-xl">
          {t('welcomeButton')}
        </Button>
      </div>
    </div>
  );
};

export default WelcomeScreen;