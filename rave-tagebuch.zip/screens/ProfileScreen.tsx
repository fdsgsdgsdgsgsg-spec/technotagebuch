import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { useLocale } from '../context/LocaleContext';
import Button from '../components/Button';
import type { Language } from '../types';
import ConfirmDeleteModal from '../components/ConfirmDeleteModal';

const ProfileScreen: React.FC = () => {
  const { currentUser, seenDjs, logout, deleteCurrentUser } = useAppContext();
  const { t, language, setLanguage } = useLocale();
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  if (!currentUser) {
    return (
      <div className="p-4 text-center">
        <p>{t('loadingProfile')}</p>
      </div>
    );
  }

  const handleConfirmDelete = () => {
    deleteCurrentUser();
    // The user will be logged out, and this component will unmount, so no need to close the modal.
  };

  const LanguageButton: React.FC<{lang: Language, label: string}> = ({ lang, label }) => {
    const isActive = language === lang;
    return (
        <button
            onClick={() => setLanguage(lang)}
            className={`px-4 py-2 text-sm font-bold rounded-full transition-all duration-200 ${
            isActive
                ? 'bg-blue-500 text-white shadow-[0_0_10px_rgba(59,130,246,0.5)]'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
        >
            {label}
        </button>
    )
  }

  return (
    <div className="p-4">
      <h1 className="text-3xl font-black uppercase text-center my-4 text-blue-400">{t('profileTitle')}</h1>
      
      <div className="flex flex-col items-center mt-8">
        <img src={currentUser.avatarUrl} alt={currentUser.username} className="w-32 h-32 rounded-full object-cover border-4 border-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.5)]" />
        <h2 className="mt-4 text-3xl font-bold text-white">{currentUser.username}</h2>
      </div>

      <div className="mt-10 grid grid-cols-2 gap-4 text-center">
        <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-800">
          <p className="text-sm uppercase text-blue-400 font-bold tracking-wider">{t('djsSeenStat')}</p>
          <p className="text-4xl font-black text-white">{seenDjs.length}</p>
        </div>
        <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-800">
          <p className="text-sm uppercase text-blue-400 font-bold tracking-wider">{t('totalPointsStat')}</p>
          <p className="text-4xl font-black text-white">{currentUser.points}</p>
        </div>
      </div>
      
      <div className="mt-10 text-center">
        <h3 className="text-lg font-bold uppercase text-blue-400 mb-3">{t('language')}</h3>
        <div className="flex justify-center space-x-4">
            <LanguageButton lang="de" label="Deutsch" />
            <LanguageButton lang="en" label="English" />
        </div>
      </div>
      
      <div className="mt-12 text-center">
        <Button onClick={logout} variant="secondary">
          {t('logoutButton')}
        </Button>
      </div>

      <div className="mt-6 text-center">
        <button
          onClick={() => setIsDeleteModalOpen(true)}
          className="text-pink-500 hover:text-pink-400 text-sm hover:underline transition-colors"
        >
          {t('deleteAccountButton')}
        </button>
      </div>

      {isDeleteModalOpen && (
        <ConfirmDeleteModal
          onClose={() => setIsDeleteModalOpen(false)}
          onConfirm={handleConfirmDelete}
        />
      )}
    </div>
  );
};

export default ProfileScreen;