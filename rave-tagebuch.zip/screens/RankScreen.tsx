import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { useLocale } from '../context/LocaleContext';
import { TrophyIcon } from '../components/icons/TrophyIcon';
import type { User } from '../types';

const RankScreen: React.FC = () => {
  const { users, currentUser, selectUser } = useAppContext();
  const { t } = useLocale();
  const [searchTerm, setSearchTerm] = useState('');

  const usersWithRank = useMemo(() => users.map((user, index) => ({
    ...user,
    rank: index + 1
  })), [users]);

  const filteredUsers = useMemo(() => 
    usersWithRank.filter(user => 
      user.username.toLowerCase().includes(searchTerm.toLowerCase())
    ), 
  [usersWithRank, searchTerm]);

  return (
    <div className="p-4">
      <h1 className="text-3xl font-black uppercase text-center my-4 text-blue-400">{t('rankTitle')}</h1>
      
      <div className="mb-4">
        <input
          type="text"
          placeholder={t('rankSearchPlaceholder')}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-gray-900 border-2 border-gray-700 rounded-full px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors"
        />
      </div>

      {filteredUsers.length > 0 ? (
        <ul className="space-y-3">
          {filteredUsers.map((user) => {
            const isCurrentUser = user.id === currentUser?.id;

            return (
              <li
                key={user.id}
                onClick={() => user.id !== currentUser?.id && selectUser(user)}
                className={`flex items-center p-4 rounded-lg transition-all ${
                  isCurrentUser 
                    ? 'bg-blue-900/50 border-2 border-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.4)]' 
                    : 'bg-gray-900/50 cursor-pointer hover:bg-gray-800/70'
                }`}
              >
                <div className="flex items-center justify-center w-12 h-10 mr-4">
                  {user.rank <= 10 ? (
                    <TrophyIcon rank={user.rank} className="w-10 h-10" />
                  ) : (
                    <span className="text-xl font-bold text-gray-500 w-10 text-center">{user.rank}</span>
                  )}
                </div>
                <img src={user.avatarUrl} alt={user.username} className="w-12 h-12 rounded-full object-cover mr-4 border-2 border-gray-700" />
                <span className={`text-lg font-bold ${isCurrentUser ? 'text-blue-300' : 'text-white'}`}>
                  {user.username}
                </span>
                <span className="ml-auto text-xl font-black text-blue-400">{user.points} {t('pointsAbbreviation')}</span>
              </li>
            );
          })}
        </ul>
      ) : (
        <p className="text-center text-gray-500 mt-8">{t('noUsersFound')}</p>
      )}
    </div>
  );
};

export default RankScreen;