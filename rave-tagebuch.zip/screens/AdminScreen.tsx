import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { useLocale } from '../context/LocaleContext';
import type { User, DJ } from '../types';
import Button from '../components/Button';
import ConfirmDeleteModal from '../components/ConfirmDeleteModal';
import EditDJModal from '../components/EditDJModal';

type AdminView = 'users' | 'djs';

const AdminScreen: React.FC = () => {
  const { users, djs, currentUser, deleteUserById, deleteDj } = useAppContext();
  const { t } = useLocale();
  const [view, setView] = useState<AdminView>('djs');
  const [itemToDelete, setItemToDelete] = useState<{ type: AdminView, item: User | DJ } | null>(null);
  const [djToEdit, setDjToEdit] = useState<DJ | null>(null);
  
  const allUsers = users.filter(u => u.id !== currentUser?.id);

  const handleConfirmDelete = () => {
    if (!itemToDelete) return;
    if (itemToDelete.type === 'users') {
      deleteUserById(itemToDelete.item.id);
    } else {
      deleteDj(itemToDelete.item.id);
    }
    setItemToDelete(null);
  };

  return (
    <div className="p-4">
      <h1 className="text-3xl font-black uppercase text-center my-4 text-blue-400">{t('adminTitle')}</h1>
      
      <div className="flex justify-center my-4 bg-gray-900 rounded-full p-1">
        <button
          onClick={() => setView('djs')}
          className={`w-1/2 py-2 text-center font-bold rounded-full transition-colors ${view === 'djs' ? 'bg-blue-500 text-white' : 'text-gray-400'}`}
        >
          {t('manageDjs')}
        </button>
        <button
          onClick={() => setView('users')}
          className={`w-1/2 py-2 text-center font-bold rounded-full transition-colors ${view === 'users' ? 'bg-blue-500 text-white' : 'text-gray-400'}`}
        >
          {t('manageUsers')}
        </button>
      </div>

      <div className="space-y-3">
        {view === 'djs' && djs.map(dj => (
          <div key={dj.id} className="bg-gray-900/50 p-3 rounded-lg flex items-center">
            <img src={dj.imageUrl} alt={dj.name} className="w-12 h-12 rounded-full object-cover mr-4" />
            <div className="flex-grow">
              <p className="font-bold text-white">{dj.name}</p>
              <p className="text-sm text-gray-400">{dj.genre}</p>
            </div>
            <div className="flex space-x-2">
              <Button onClick={() => setDjToEdit(dj)} className="px-3 py-1 text-xs">{t('editButton')}</Button>
              <Button onClick={() => setItemToDelete({ type: 'djs', item: dj })} className="bg-pink-600 px-3 py-1 text-xs">{t('deleteButton')}</Button>
            </div>
          </div>
        ))}
        {view === 'users' && allUsers.map(user => (
          <div key={user.id} className="bg-gray-900/50 p-3 rounded-lg flex items-center">
             <img src={user.avatarUrl} alt={user.username} className="w-12 h-12 rounded-full object-cover mr-4" />
            <div className="flex-grow">
              <p className="font-bold text-white">{user.username}</p>
              <p className="text-sm text-gray-400">{user.points} {t('pointsAbbreviation')}</p>
            </div>
             <Button onClick={() => setItemToDelete({ type: 'users', item: user })} className="bg-pink-600 px-3 py-1 text-xs">{t('deleteButton')}</Button>
          </div>
        ))}
      </div>

      {itemToDelete && (
        <ConfirmDeleteModal
          onClose={() => setItemToDelete(null)}
          onConfirm={handleConfirmDelete}
          title={itemToDelete.type === 'users' ? t('confirmDeleteUserTitle') : t('confirmDeleteDjTitle')}
          message={itemToDelete.type === 'users' ? t('confirmDeleteUserMessage') : t('confirmDeleteDjMessage')}
        />
      )}
      
      {djToEdit && (
          <EditDJModal dj={djToEdit} onClose={() => setDjToEdit(null)} />
      )}
    </div>
  );
};

export default AdminScreen;