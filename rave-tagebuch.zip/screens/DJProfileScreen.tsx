import React, { useState, useEffect } from 'react';
import type { DJ, Event } from '../types';
import { useAppContext } from '../context/AppContext';
import { useLocale } from '../context/LocaleContext';
import Button from '../components/Button';
import { ArrowLeftIcon } from '../components/icons/ArrowLeftIcon';
import { findUpcomingEvents } from '../services/geminiService';
import MarkAsSeenModal from '../components/MarkAsSeenModal';

interface DJProfileScreenProps {
  dj: DJ;
}

const DJProfileScreen: React.FC<DJProfileScreenProps> = ({ dj }) => {
  const { selectDJ } = useAppContext();
  const { t, language } = useLocale();
  const [events, setEvents] = useState<Event[]>([]);
  const [isLoadingEvents, setIsLoadingEvents] = useState(false);
  const [isMarkAsSeenModalOpen, setMarkAsSeenModalOpen] = useState(false);
  const [loadingMessageIndex, setLoadingMessageIndex] = useState(0);
  
  const loadingMessages = [
    t('loadingEventsMessage1'),
    t('loadingEventsMessage2'),
    t('loadingEventsMessage3'),
    t('loadingEventsMessage4'),
  ];

  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | undefined;
    if (isLoadingEvents) {
      interval = setInterval(() => {
        setLoadingMessageIndex(prevIndex => (prevIndex + 1) % loadingMessages.length);
      }, 2500);
    }
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isLoadingEvents, loadingMessages.length]);


  useEffect(() => {
    const fetchEvents = async () => {
      setIsLoadingEvents(true);
      const foundEvents = await findUpcomingEvents(dj.name, language);
      if (foundEvents) {
        setEvents(foundEvents);
      }
      setIsLoadingEvents(false);
    };
    fetchEvents();
  }, [dj.name, language]);

  return (
    <div className="animate-fade-in">
      <div className="relative h-64">
        <img src={dj.imageUrl.replace('400/400', '600/400')} alt={dj.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
        <button 
          onClick={() => selectDJ(null)} 
          className="absolute top-4 left-4 bg-black/50 p-2 rounded-full text-white hover:bg-black/80 transition-colors"
        >
          <ArrowLeftIcon />
        </button>
        <div className="absolute bottom-4 left-4">
          <h1 className="text-4xl font-black uppercase text-white tracking-tighter">{dj.name}</h1>
          <p className="text-lg font-bold text-blue-400">{dj.genre} - {dj.city}</p>
        </div>
      </div>

      <div className="p-4">
        <Button onClick={() => setMarkAsSeenModalOpen(true)} className="w-full">
          {t('addToDiaryButton')}
        </Button>

        <div className="mt-6">
          <h2 className="text-2xl font-bold uppercase text-blue-400 mb-2">{t('aboutTitle')}</h2>
          <p className="text-gray-400 leading-relaxed">{dj.bio}</p>
        </div>
        
        <div className="mt-6">
          <h2 className="text-2xl font-bold uppercase text-blue-400 mb-2">{t('upcomingEventsTitle')}</h2>
          {isLoadingEvents ? (
             <div className="flex justify-center items-center p-4">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
                <p className="ml-3 text-blue-400 transition-opacity duration-500">{loadingMessages[loadingMessageIndex]}</p>
             </div>
          ) : events.length > 0 ? (
            <ul className="space-y-3">
              {events.map(event => (
                <li key={event.id} className="bg-gray-900/50 p-3 rounded-lg">
                  <p className="font-bold text-white">{event.name}</p>
                  <p className="text-sm text-gray-400">{event.venue} - {event.date}</p>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500">{t('noUpcomingEvents')}</p>
          )}
        </div>
      </div>
      {isMarkAsSeenModalOpen && (
        <MarkAsSeenModal
          dj={dj}
          onClose={() => setMarkAsSeenModalOpen(false)}
        />
      )}
    </div>
  );
};

export default DJProfileScreen;